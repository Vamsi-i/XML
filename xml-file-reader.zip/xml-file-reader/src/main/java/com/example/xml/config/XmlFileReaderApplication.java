package com.example.xml.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import com.example.xml.service.XmlFileReaderService;

@SpringBootApplication
@ComponentScan(basePackages = {"com.example"})
public class XmlFileReaderApplication extends SpringBootServletInitializer {


	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(XmlFileReaderApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(XmlFileReaderApplication.class, args);
		
	}

}
