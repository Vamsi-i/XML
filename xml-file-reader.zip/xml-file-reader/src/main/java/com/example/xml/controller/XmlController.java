package com.example.xml.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.xml.model.SCL;
import com.example.xml.service.XmlFileReaderService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class XmlController {

	@Autowired
	private XmlFileReaderService xmlFileReader;

	@GetMapping(value = "/xml", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Map<String, String>> getData() {
		log.info("XmlController   >>  getData()   Started");
		xmlFileReader.readAllXmlFiles();
		Map<String, String> status = new HashMap<>();
		log.info("Match Merge Completed");
		status.put("message", "Match Merge Completed");
		log.info("XmlController   >>  getData()   Ended");
		return ResponseEntity.ok(status);
	}

}
