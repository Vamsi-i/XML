package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Address {
	String textContent = "";
	@JsonProperty("P")
	List<P> pList = new ArrayList<>();

	public Address updateAddress(Address address) {

		if (CollectionUtils.isEmpty(pList)) {
			this.pList.addAll(address.getPList());
		} else {


			List<P> newRecords = new ArrayList<>();
			address.getPList().forEach(data -> {
				boolean isDuplicate = false;
				for (P newR : this.pList) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.pList.addAll(newRecords);
		}

		return this;
	}

}