package com.example.xml.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Communication {
	String textContent = "";
	@JsonProperty("SubNetwork")
	List<SubNetwork> subNetwork = new ArrayList<>();

	public void updateCommunications(Communication communication) {

		if (CollectionUtils.isEmpty(this.subNetwork)) {
			subNetwork.addAll(communication.getSubNetwork());
		} else {

			List<SubNetwork> newRecords = new ArrayList<SubNetwork>();

			communication.getSubNetwork().forEach(data -> {
				boolean isDuplicate = false;
				for (SubNetwork newR : this.subNetwork) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					}else {
						data.supdateSubNetWork(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});

			subNetwork.addAll(newRecords);
		}

	}

}