package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ConnectedAP {
	String apName = "";
	String iedName = "";
	String redProt = "";
	String textContent = "";
	@JsonProperty("Address")
	Address address;
	@JsonProperty("GSE")
	List<GSE> gSEList = new ArrayList<>();

	public ConnectedAP updateconnectedAP(ConnectedAP connectedAP) {

		this.address.updateAddress(connectedAP.getAddress());

		if (CollectionUtils.isEmpty(gSEList)) {
			gSEList.addAll(connectedAP.getGSEList());
		} else {

			List<GSE> newRecords = new ArrayList<>();
			connectedAP.getGSEList().forEach(data -> {
				boolean isDuplicate = false;
				for (GSE newR : this.gSEList) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					} else {
						data.updateGSE(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.gSEList.addAll(newRecords);

		}

		return this;
	}

	public boolean compareObject(ConnectedAP connectedAP) {

		return Objects.equals(this.apName, connectedAP.getApName())
				&& Objects.equals(this.iedName, connectedAP.getIedName())
				&& Objects.equals(this.redProt, connectedAP.getRedProt());
	}

}