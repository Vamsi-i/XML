package com.example.xml.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class DA {
	Val val;
    String bType="";
    String dchg="";
    String fc="";
    String name="";
    String type="";
    String valKind="";
    String textContent="";
	public boolean compareObject(DA newR) {
		return this.equals(newR);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DA other = (DA) obj;
		if (bType == null) {
			if (other.bType != null)
				return false;
		} else if (!bType.equals(other.bType))
			return false;
		if (dchg == null) {
			if (other.dchg != null)
				return false;
		} else if (!dchg.equals(other.dchg))
			return false;
		if (fc == null) {
			if (other.fc != null)
				return false;
		} else if (!fc.equals(other.fc))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (textContent == null) {
			if (other.textContent != null)
				return false;
		} else if (!textContent.equals(other.textContent))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (valKind == null) {
			if (other.valKind != null)
				return false;
		} else if (!valKind.equals(other.valKind))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bType == null) ? 0 : bType.hashCode());
		result = prime * result + ((dchg == null) ? 0 : dchg.hashCode());
		result = prime * result + ((fc == null) ? 0 : fc.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((textContent == null) ? 0 : textContent.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((valKind == null) ? 0 : valKind.hashCode());
		return result;
	}
 
}