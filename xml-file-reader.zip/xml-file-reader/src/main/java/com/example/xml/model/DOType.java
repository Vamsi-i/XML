package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DOType {
	String cdc = "";
	String id = "";
	String textContent = "";
	@JsonProperty("DA")
	List<DA> dAList = new ArrayList<>();
	List<SDO> sDO =   new ArrayList<>();
	ProtNs  protNs;

	public boolean compareObject(DOType newR) {
		// TODO Auto-generated method stub
		return this.equals(newR);
	}

	public void updateDOType(DOType newR) {

		if (CollectionUtils.isEmpty(dAList)) {
			dAList.addAll(newR.getDAList());
		} else {

			List<DA> newRecords = new ArrayList<>();
			newR.getDAList().forEach(data -> {
				boolean isDuplicate = false;
				for (DA da : this.dAList) {
					if (data.compareObject(da)) {
						isDuplicate = true;
						break;
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.dAList.addAll(newRecords);

		
		}
		
		
		

		if (CollectionUtils.isEmpty(sDO)) {
			sDO.addAll(newR.getSDO());
		} else {

			List<SDO> newRecords = new ArrayList<>();
			newR.getSDO().forEach(data -> {
				boolean isDuplicate = false;
				for (SDO da : this.sDO) {
					if (data.compareObject(da)) {
						isDuplicate = true;
						break;
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.sDO.addAll(newRecords);

		}

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DOType other = (DOType) obj;
		if (cdc == null) {
			if (other.cdc != null)
				return false;
		} else if (!cdc.equals(other.cdc))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (textContent == null) {
			if (other.textContent != null)
				return false;
		} else if (!textContent.equals(other.textContent))
			return false;
		return true;
	}

}
