package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class DataTypeTemplates {
	
	String textContent = "";
	@JsonProperty("DOType")
	List<DOType> dOTypes = new ArrayList<>();
	
	@JsonProperty("DAType")
	List<DOType> dATypes = new ArrayList<>();
	@JsonProperty("EnumType")
	List<EnumType> enumType = new ArrayList<>();
	@JsonProperty("LNodeType")
	List<LNodeType> lNodeType = new ArrayList<>();

	public void updateDataTypes(DataTypeTemplates dataTypeTemplates) {

		if (CollectionUtils.isEmpty(dOTypes)) {
			dOTypes.addAll(dataTypeTemplates.getDOTypes());
		} else {

			List<DOType> newRecords = new ArrayList<>();
			dataTypeTemplates.getDOTypes().forEach(data -> {
				boolean isDuplicate = false;
				for (DOType newR : this.dOTypes) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					} else {
						data.updateDOType(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.dOTypes.addAll(newRecords);

		}
		
		
		
		if (CollectionUtils.isEmpty(dATypes)) {
			dATypes.addAll(dataTypeTemplates.getDATypes());
		} else {

			List<DOType> newRecords = new ArrayList<>();
			dataTypeTemplates.getDATypes().forEach(data -> {
				boolean isDuplicate = false;
				for (DOType newR : this.dATypes) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					} else {
						data.updateDOType(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.dATypes.addAll(newRecords);

		}

		if (CollectionUtils.isEmpty(enumType)) {
			enumType.addAll(dataTypeTemplates.getEnumType());
		} else {

			List<EnumType> newRecords = new ArrayList<>();
			dataTypeTemplates.getEnumType().forEach(data -> {
				boolean isDuplicate = false;
				for (EnumType newR : this.enumType) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					} else {
						data.updateEnumType(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.enumType.addAll(newRecords);

		}
		
		
		
		
		
		
		
		
		if (CollectionUtils.isEmpty(lNodeType)) {
			lNodeType.addAll(dataTypeTemplates.getLNodeType());
		} else {

			List<LNodeType> newRecords = new ArrayList<>();
			dataTypeTemplates.getLNodeType().forEach(data -> {
				boolean isDuplicate = false;
				for (LNodeType newR : this.lNodeType) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					} else {
						data.updategetLNodeType(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.lNodeType.addAll(newRecords);

		}


	}

}