package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class GSE {
	String cbName = "";
	String ldInst = "";
	String textContent = "";
	String isMulti = "";
	@JsonProperty("Address")
	List<Address> addressList = new ArrayList<>();
	@JsonProperty("MaxTime")
	MaxTime maxTime;
	@JsonProperty("MinTime")
	MinTime minTime;
	@JsonProperty("Private")
	List<Private> privateList = new ArrayList<>();

	public GSE updateGSE(GSE g) {

		if (CollectionUtils.isEmpty(this.addressList)) {
			this.addressList = g.getAddressList();
		} else {

			this.addressList = g.getAddressList().stream().map(a -> a.updateAddress(a)).collect(Collectors.toList());
		}

		if (CollectionUtils.isEmpty(this.privateList)) {
			this.privateList = g.getPrivateList();
		} else {
			

			List<Private> newRecords = new ArrayList<>();
			g.getPrivateList().forEach(data -> {
				boolean isDuplicate = false;
				for (Private newR : this.privateList) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.privateList.addAll(newRecords);

		}

		return this;
	}

	public boolean compareObject(GSE gse) {

		return Objects.equals(this.cbName, gse.getCbName()) && Objects.equals(this.ldInst, gse.getLdInst())
				&& Objects.equals(this.isMulti, gse.getIsMulti());
	}

}