package com.example.xml.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class IED {
	String desc = "";
	String manufacturer = "";
	String name = "";
	String originalSclRelease = "";
	String originalSclRevision = "";
	String originalSclVersion = "";
	String type = "";
	String textContent = "";
	@JsonProperty("AccessPoint")
	AccessPoint accessPoint;
	@JsonProperty("Private")
	Private private1;
	@JsonProperty("Services")
	Services services;

}