package com.example.xml.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@XmlAccessorType(XmlAccessType.FIELD)
public class LN0 {
	String inst = "";
	String lnClass = "";
	String lnType = "";
	String textContent = "";
	@JsonProperty("DOI")
	DOI dOI;
	@JsonProperty("Inputs")
	Inputs inputs;
}