package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LNodeType {
	String id = "";
	String lnClass = "";
	String textContent = "";
	@JsonProperty("DO")
	List<DO> dOs = new ArrayList<>();

	public boolean compareObject(LNodeType newR) {
		return this.equals(newR);
	}

	public void updategetLNodeType(LNodeType type) {

		if (CollectionUtils.isEmpty(dOs)) {
			dOs.addAll(type.getDOs());
		} else {

			List<DO> newRecords = new ArrayList<>();
			type.getDOs().forEach(data -> {
				boolean isDuplicate = false;
				for (DO da : this.dOs) {
					if (data.compareObject(da)) {
						isDuplicate = true;
						break;
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.dOs.addAll(newRecords);

		}

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LNodeType other = (LNodeType) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lnClass == null) {
			if (other.lnClass != null)
				return false;
		} else if (!lnClass.equals(other.lnClass))
			return false;
		if (textContent == null) {
			if (other.textContent != null)
				return false;
		} else if (!textContent.equals(other.textContent))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lnClass == null) ? 0 : lnClass.hashCode());
		result = prime * result + ((textContent == null) ? 0 : textContent.hashCode());
		return result;
	}

}