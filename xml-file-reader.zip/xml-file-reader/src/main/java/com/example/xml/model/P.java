package com.example.xml.model;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class P {
	String type = "";
	String textContent = "";

	public boolean compareObject(P p) {
		return Objects.equals(this.type, p.getType()) && Objects.equals(this.textContent, p.getTextContent());
	}



}