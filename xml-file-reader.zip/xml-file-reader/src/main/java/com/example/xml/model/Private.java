package com.example.xml.model;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Private {
	String type = "";
	String textContent = "";

	public Private updatePrivate(Private a) {
		
		this.type = a.getType();
		this.textContent = a.getTextContent();
		return this;
	}

	public boolean compareObject(Private newR) {
		// TODO Auto-generated method stub
		return Objects.equals(this.type, newR.getType()) && 
				 Objects.equals(this.textContent, newR.getTextContent());
	}
	
	
	

}