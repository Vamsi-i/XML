package com.example.xml.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ReportSettings {
    String bufTime="";
    String cbName="";
    String datSet="";
    String intgPd="";
    String optFields="";
    String owner="";
    String resvTms="";
    String rptID="";
    String trgOps="";
    String textContent="";
  }