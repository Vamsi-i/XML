package com.example.xml.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SCL {
	String release = "";
	String revision = "";
	String schemaLocation = "";
	String version = "";
	String textContent = "";
	@JsonProperty("Communication")
	Communication communication;
	@JsonProperty("DataTypeTemplates")
	DataTypeTemplates dataTypeTemplates;
	@JsonProperty("Header")
	Header header;
	@JsonProperty("IED")
	IED iED;
	
	
	
	public void updateObject(SCL data) {
		this.header = new Header("Template", "0","0", "");
		this.communication.updateCommunications(data.getCommunication());	
		this.dataTypeTemplates.updateDataTypes(data.getDataTypeTemplates());
	}
	
	

	
}