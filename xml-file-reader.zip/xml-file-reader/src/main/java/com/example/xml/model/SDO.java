package com.example.xml.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class SDO {
	String name;
	String type;
	String count;
	public boolean compareObject(SDO da) {
		// TODO Auto-generated method stub
		return this.equals(da);
	}
}
