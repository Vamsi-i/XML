package com.example.xml.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Services {
	String confLNs = "";
	String dataObjectDirectory = "";
	String dataSetDirectory = "";
	String fileHandling = "";
	String gSESettings = "";
	String getCBValues = "";
	String getDataObjectDefinition = "";
	String getDataSetValue = "";
	String getDirectory = "";
	String readWrite = "";
	String nameLength = "";
	String textContent = "";
	@JsonProperty("ClientServices")
	ClientServices clientServices;
	@JsonProperty("ConfDataSet")
	ConfDataSet confDataSet;
	@JsonProperty("ConfReportControl")
	ConfReportControl confReportControl;
	@JsonProperty("DynAssociation")
	DynAssociation dynAssociation;
	@JsonProperty("GOOSE")
	GOOSE gOOSE;
	@JsonProperty("ReportSettings")
	ReportSettings reportSettings;



}