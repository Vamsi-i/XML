package com.example.xml.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class SubNetwork {
	String name = "";
	String type = "";
	String desc;
	String textContent = "";
	@JsonProperty("ConnectedAP")
	List<ConnectedAP> connectedAP = new ArrayList<>();
	@JsonProperty("BitRate")
	BitRate bitRate;

	public SubNetwork supdateSubNetWork(SubNetwork subNetwork) {

		if (CollectionUtils.isEmpty(connectedAP)) {
			connectedAP.addAll(subNetwork.getConnectedAP());
		} else {

			List<ConnectedAP> newRecords = new ArrayList<>();
			subNetwork.getConnectedAP().forEach(data -> {
				boolean isDuplicate = false;
				for (ConnectedAP newR : this.connectedAP) {
					if (data.compareObject(newR)) {
						isDuplicate = true;
						break;
					} else {
						data.updateconnectedAP(newR);
					}
				}

				if (!isDuplicate) {
					newRecords.add(data);
				}

			});
			this.connectedAP.addAll(newRecords);

		}

		return this;

	}

	public boolean compareObject(SubNetwork subNetwork) {

		return Objects.equals(this.name, subNetwork.getName()) && Objects.equals(this.type, subNetwork.getType());

	}

}