package com.example.xml.service;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;

import com.example.xml.model.SCL;
import com.example.xml.utils.BeanToXMLUtil;
import com.example.xml.utils.XMLDocumentWriter;
import com.example.xml.utils.XMLToBeanObjUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class XmlFileReaderService {

	private static String masterFilePath = "C:\\Users\\NagendraMarri\\Desktop\\POC\\xml-file-reader\\xml\\writer\\MasterSCD.scd";

	public SCL performMatchMerge(List<SCL> bcScl, SCL muScl) {
		log.info("XmlFileReaderService   >>  performMatchMerge()   Started");
//		log.info("MU   {}", muScl);
		bcScl.forEach(data -> {

//			log.info("data  {}", data);

			if (Objects.nonNull(data)) {

//				log.info("------------------------------");
				muScl.updateObject(data);
			}
		});

//		log.info("MU   {}", muScl);

		Document convertBeanToXML = BeanToXMLUtil.convertBeanToXML(muScl);
		if (Objects.nonNull(convertBeanToXML))
			XMLDocumentWriter.write(convertBeanToXML, masterFilePath, true, true);
		log.info("XmlFileReaderService   >>  performMatchMerge()   Ended");
		return muScl;

	}

	public void readAllXmlFiles() {
		log.info("XmlFileReaderService   >>  readAllXmlFiles()   Started");
		List<String> bc360Files = Arrays.asList("xml/BC360_PX2.IID", "xml/BC360_PX1.IID");

		List<SCL> bcScl = bc360Files.parallelStream()
				.map(data -> XMLToBeanObjUtil.convertXmlToBeanObject(loadDataFromFile(data)))
				.collect(Collectors.toList());

		SCL muScl = XMLToBeanObjUtil.convertXmlToBeanObject(loadDataFromFile("xml/MU360.IID"));
		this.performMatchMerge(bcScl, muScl);

		log.info("XmlFileReaderService   >>  readAllXmlFiles()   Ended");
	}

	private Document loadDataFromFile(String data) {
		
		log.info("XmlFileReaderService   >>  loadDataFromFile()   Started");
		Document doc;
		try {
			File xmlFile = ResourceUtils.getFile("classpath:" + data);

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(xmlFile);
			
			log.info("XmlFileReaderService   >>  loadDataFromFile()   Ended");
			return doc;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

}
