
package com.example.xml.utils;

import java.util.List;
import java.util.Objects;

import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.example.xml.model.AccessPoint;
import com.example.xml.model.Address;
import com.example.xml.model.BitRate;
import com.example.xml.model.ClientServices;
import com.example.xml.model.Communication;
import com.example.xml.model.ConfDataSet;
import com.example.xml.model.ConfReportControl;
import com.example.xml.model.ConnectedAP;
import com.example.xml.model.DA;
import com.example.xml.model.DAI;
import com.example.xml.model.DO;
import com.example.xml.model.DOI;
import com.example.xml.model.DOType;
import com.example.xml.model.DataTypeTemplates;
import com.example.xml.model.DynAssociation;
import com.example.xml.model.EnumType;
import com.example.xml.model.EnumVal;
import com.example.xml.model.ExtRef;
import com.example.xml.model.GOOSE;
import com.example.xml.model.GSE;
import com.example.xml.model.Header;
import com.example.xml.model.IED;
import com.example.xml.model.Inputs;
import com.example.xml.model.LDevice;
import com.example.xml.model.LN;
import com.example.xml.model.LN0;
import com.example.xml.model.LNodeType;
import com.example.xml.model.MaxTime;
import com.example.xml.model.MinTime;
import com.example.xml.model.P;
import com.example.xml.model.Private;
import com.example.xml.model.ReportSettings;
import com.example.xml.model.SCL;
import com.example.xml.model.SDO;
import com.example.xml.model.Server;
import com.example.xml.model.Services;
import com.example.xml.model.SubNetwork;
import com.example.xml.model.Val;

public class BeanToXMLUtil {
	@SuppressWarnings("deprecation")
	public static Document convertBeanToXML(SCL sCL) {
		Document inputDoc;
		try {
			inputDoc = XMLUtil.createDocument("SCL");

			inputDoc.setXmlVersion("1.0");
			inputDoc.setXmlStandalone(true);
			Element sCLElm = inputDoc.getDocumentElement();
			sCLElm.setTextContent(sCL.getTextContent());
			sCLElm.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
			sCLElm.setAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
			sCLElm.setAttribute("xsi:schemaLocation", "http://www.iec.ch/61850/2003/SCL SCL.xsd");
			sCLElm.setAttribute("xmlns", "http://www.iec.ch/61850/2003/SCL");
			sCLElm.setAttribute("release", sCL.getRelease());
			sCLElm.setAttribute("revision", sCL.getRevision());
			sCLElm.setAttribute("schemaLocation", sCL.getSchemaLocation());
			sCLElm.setAttribute("version", sCL.getVersion());

			Element headerElm = XMLUtil.createChildElement(sCLElm, "Header");
			Header header = sCL.getHeader();
			headerElm.setTextContent(header.getTextContent());

			headerElm.setAttribute("id", header.getId());
			headerElm.setAttribute("revision", header.getRevision());
			headerElm.setAttribute("version", header.getVersion());

			Element communicationElm = XMLUtil.createChildElement(sCLElm, "Communication");
			Communication communication = sCL.getCommunication();
			communicationElm.setTextContent(communication.getTextContent());

			List<SubNetwork> subNetworks = communication.getSubNetwork();

			subNetworks.forEach(subNetwork -> {

				Element subNetworkElm = XMLUtil.createChildElement(communicationElm, "SubNetwork");
				subNetworkElm.setTextContent(subNetwork.getTextContent());

				subNetworkElm.setAttribute("name", subNetwork.getName());
				subNetworkElm.setAttribute("type", subNetwork.getType());

				Element biteElm = XMLUtil.createChildElement(subNetworkElm, "BitRate");

				BitRate bitRate = subNetwork.getBitRate();
				biteElm.setAttribute("unit", bitRate.getUnit());
				biteElm.setAttribute("multiplier", bitRate.getMultiplier());
				biteElm.setTextContent(communication.getTextContent());

				subNetwork.setBitRate(bitRate);

				List<ConnectedAP> connectedAPs = subNetwork.getConnectedAP();
				connectedAPs.forEach(connectedAP -> {

					Element connectedAPElm = XMLUtil.createChildElement(subNetworkElm, "ConnectedAP");

					connectedAPElm.setTextContent(connectedAP.getTextContent());

					connectedAPElm.setAttribute("apName", connectedAP.getApName());
					connectedAPElm.setAttribute("iedName", connectedAP.getIedName());
					connectedAPElm.setAttribute("redProt", connectedAP.getRedProt());

					Element addressElm = XMLUtil.createChildElement(connectedAPElm, "Address");

					Address address = connectedAP.getAddress();
					// addressElm.setTextContent(address.getTextContent());
					List<P> pList = address.getPList();

					pList.forEach(p -> {
						Element pElm = XMLUtil.createChildElement(addressElm, "P");
						pElm.setAttribute("type", p.getType());
						pElm.setTextContent(p.getTextContent());
					});

					// REPEAt elm

					List<GSE> gSEs = connectedAP.getGSEList();
					gSEs.forEach(gSE -> {

						Element gSEElm = XMLUtil.createChildElement(connectedAPElm, "GSE");
						gSEElm.setTextContent(gSE.getTextContent());

						gSEElm.setAttribute("cbName", gSE.getCbName());
						gSEElm.setAttribute("ldInst", gSE.getLdInst());

						List<Address> address1s = gSE.getAddressList();
						Element addressElm1 = XMLUtil.createChildElement(gSEElm, "Address");
						address1s.forEach(address1 -> {
							// addressElm1.setTextContent(address1.getTextContent());
							List<P> pList2 = address1.getPList();
							pList2.forEach(p -> {
								Element pElm = XMLUtil.createChildElement(addressElm1, "P");
								pElm.setTextContent(p.getTextContent());
								pElm.setAttribute("type", p.getType());
								addressElm1.appendChild(pElm);
							});
						});

						// REPEAt elm
						Element maxTimeElm = XMLUtil.createChildElement(gSEElm, "MaxTime");
						MaxTime maxTime = gSE.getMaxTime();
						maxTimeElm.setTextContent(maxTime.getTextContent());

						maxTimeElm.setAttribute("multiplier", maxTime.getMultiplier());
						maxTimeElm.setAttribute("unit", maxTime.getUnit());

						Element minTimeElm = XMLUtil.createChildElement(gSEElm, "MinTime");
						MinTime minTime = gSE.getMinTime();
						minTimeElm.setTextContent(minTime.getTextContent());

						minTimeElm.setAttribute("multiplier", minTime.getMultiplier());
						minTimeElm.setAttribute("unit", minTime.getUnit());

						List<Private> private1s = gSE.getPrivateList();

						private1s.forEach(private1 -> {

							Element privateElm = XMLUtil.createChildElement(gSEElm, "Private");
							privateElm.setTextContent(private1.getTextContent());

							privateElm.setAttribute("type", private1.getType());
						});

					});

				});

			});

			Element iEDElm = XMLUtil.createChildElement(sCLElm, "IED");
			IED iED = sCL.getIED();
			iEDElm.setTextContent(iED.getTextContent());

			iEDElm.setAttribute("desc", iED.getDesc());
			iEDElm.setAttribute("manufacturer", iED.getManufacturer());
			iEDElm.setAttribute("name", iED.getName());
			iEDElm.setAttribute("originalSclRelease", iED.getOriginalSclRelease());
			iEDElm.setAttribute("originalSclRevision", iED.getOriginalSclRevision());
			iEDElm.setAttribute("originalSclVersion", iED.getOriginalSclVersion());
			iEDElm.setAttribute("type", iED.getType());

			Element accessPointElm = XMLUtil.createChildElement(iEDElm, "AccessPoint");
			AccessPoint accessPoint = iED.getAccessPoint();
			accessPointElm.setTextContent(accessPoint.getTextContent());

			accessPointElm.setAttribute("name", accessPoint.getName());

			Element serverElm = XMLUtil.createChildElement(accessPointElm, "Server");
			Server server = accessPoint.getServer();
			serverElm.setTextContent(server.getTextContent());

			Element lDeviceElm = XMLUtil.createChildElement(serverElm, "LDevice");
			LDevice lDevice = server.getLDevice();
			lDeviceElm.setTextContent(lDevice.getTextContent());

			lDeviceElm.setAttribute("desc", lDevice.getDesc());
			lDeviceElm.setAttribute("inst", lDevice.getInst());
			lDeviceElm.setAttribute("ldName", lDevice.getLdName());

			for (int l = 0; l < lDevice.getLNList().size(); l++) {
				LN lN = lDevice.getLNList().get(l);
				Element lNElm = XMLUtil.createChildElement(lDeviceElm, "LN");
				lNElm.setTextContent(lN.getTextContent());

				lNElm.setAttribute("inst", lN.getInst());
				lNElm.setAttribute("lnClass", lN.getLnClass());
				lNElm.setAttribute("lnType", lN.getLnType());

				Element dOIElm0 = XMLUtil.createChildElement(lNElm, "DOI");
				DOI dOI0 = lN.getDOI();
				dOIElm0.setTextContent(dOI0.getTextContent());

				dOIElm0.setAttribute("name", dOI0.getName());

				for (int m = 0; m < dOI0.getDAIList().size(); m++) {
					DAI dAI = dOI0.getDAIList().get(m);
					Element dAIElm = XMLUtil.createChildElement(dOIElm0, "DAI");
					dAIElm.setTextContent(dAI.getTextContent());

					dAIElm.setAttribute("Val", dAI.getVal());
					dAIElm.setAttribute("name", dAI.getName());
					dAIElm.setAttribute("valImport", dAI.getValImport());
					dAIElm.setAttribute("valKind", dAI.getValKind());

				} // REPEAt elm } // REPEAt elm
				for (int n = 0; n < lDevice.getLN0List().size(); n++) {
					LN0 lN0 = lDevice.getLN0List().get(n);

					Element lN0Elm = XMLUtil.createChildElement(lDeviceElm, "LN0");
					lN0Elm.setTextContent(lN0.getTextContent());

					lN0Elm.setAttribute("inst", lN0.getInst());
					lN0Elm.setAttribute("lnClass", lN0.getLnClass());
					lN0Elm.setAttribute("lnType", lN0.getLnType());

					Element dOIElm = XMLUtil.createChildElement(lN0Elm, "DOI");
					DOI dOI = lN0.getDOI();
					dOIElm.setTextContent(dOI.getTextContent());

					dOIElm.setAttribute("name", dOI.getName());

					for (int o = 0; o < dOI.getDAIList().size(); o++) {
						DAI dAI = dOI.getDAIList().get(o);
						Element dAIElm = XMLUtil.createChildElement(dOIElm, "DAI");
						dAIElm.setTextContent(dAI.getTextContent());

						dAIElm.setAttribute("name", dAI.getName());
						dAIElm.setAttribute("sAddr", dAI.getSAddr());

					} // REPEAt elm
					Element inputsElm = XMLUtil.createChildElement(lN0Elm, "Inputs");
					Inputs inputs = lN0.getInputs();
					inputsElm.setTextContent(inputs.getTextContent());

					Element extRefElm = XMLUtil.createChildElement(inputsElm, "ExtRef");
					ExtRef extRef = inputs.getExtRef();
					extRefElm.setTextContent(extRef.getTextContent());

					extRefElm.setAttribute("desc", extRef.getDesc());
					extRefElm.setAttribute("intAddr", extRef.getIntAddr());
					extRefElm.setAttribute("pDA", extRef.getPDA());
					extRefElm.setAttribute("pDO", extRef.getPDO());
					extRefElm.setAttribute("pLN", extRef.getPLN());

				}
				// REPEAt elm
				Element privateElm1 = XMLUtil.createChildElement(iEDElm, "Private");
				Private private2 = iED.getPrivate1();
				privateElm1.setTextContent(private2.getTextContent());

				privateElm1.setAttribute("type", private2.getType());

				Element servicesElm = XMLUtil.createChildElement(iEDElm, "Services");
				Services services = iED.getServices();
				servicesElm.setTextContent(services.getTextContent());

				servicesElm.setAttribute("ConfLNs", services.getConfLNs());
				servicesElm.setAttribute("DataObjectDirectory", services.getDataObjectDirectory());
				servicesElm.setAttribute("DataSetDirectory", services.getDataSetDirectory());
				servicesElm.setAttribute("FileHandling", services.getFileHandling());
				servicesElm.setAttribute("GSESettings", services.getGSESettings());
				servicesElm.setAttribute("GetCBValues", services.getGetCBValues());
				servicesElm.setAttribute("GetDataObjectDefinition", services.getGetDataObjectDefinition());
				servicesElm.setAttribute("GetDataSetValue", services.getGetDataSetValue());
				servicesElm.setAttribute("GetDirectory", services.getGetDirectory());
				servicesElm.setAttribute("ReadWrite", services.getReadWrite());
				servicesElm.setAttribute("nameLength", services.getNameLength());

				Element clientServicesElm = XMLUtil.createChildElement(servicesElm, "ClientServices");
				ClientServices clientServices = services.getClientServices();
				clientServicesElm.setTextContent(clientServices.getTextContent());

				clientServicesElm.setAttribute("TimeSyncProt", clientServices.getTimeSyncProt());

				Element confDataSetElm = XMLUtil.createChildElement(servicesElm, "ConfDataSet");
				ConfDataSet confDataSet = services.getConfDataSet();
				confDataSetElm.setTextContent(confDataSet.getTextContent());

				confDataSetElm.setAttribute("max", confDataSet.getMax());
				confDataSetElm.setAttribute("maxAttributes", confDataSet.getMaxAttributes());
				confDataSetElm.setAttribute("modify", confDataSet.getModify());

				Element confReportControlElm = XMLUtil.createChildElement(servicesElm, "ConfReportControl");
				ConfReportControl confReportControl = services.getConfReportControl();
				confReportControlElm.setTextContent(confReportControl.getTextContent());

				confReportControlElm.setAttribute("bufConf", confReportControl.getBufConf());
				confReportControlElm.setAttribute("max", confReportControl.getMax());

				Element dynAssociationElm = XMLUtil.createChildElement(servicesElm, "DynAssociation");
				DynAssociation dynAssociation = services.getDynAssociation();
				dynAssociationElm.setTextContent(dynAssociation.getTextContent());

				dynAssociationElm.setAttribute("max", dynAssociation.getMax());

				Element gOOSEElm = XMLUtil.createChildElement(servicesElm, "GOOSE");
				GOOSE gOOSE = services.getGOOSE();
				gOOSEElm.setTextContent(gOOSE.getTextContent());

				gOOSEElm.setAttribute("max", gOOSE.getMax());

				Element reportSettingsElm = XMLUtil.createChildElement(servicesElm, "ReportSettings");
				ReportSettings reportSettings = services.getReportSettings();
				reportSettingsElm.setTextContent(reportSettings.getTextContent());

				reportSettingsElm.setAttribute("bufTime", reportSettings.getBufTime());
				reportSettingsElm.setAttribute("cbName", reportSettings.getCbName());
				reportSettingsElm.setAttribute("datSet", reportSettings.getDatSet());
				reportSettingsElm.setAttribute("intgPd", reportSettings.getIntgPd());
				reportSettingsElm.setAttribute("optFields", reportSettings.getOptFields());
				reportSettingsElm.setAttribute("owner", reportSettings.getOwner());
				reportSettingsElm.setAttribute("resvTms", reportSettings.getResvTms());
				reportSettingsElm.setAttribute("rptID", reportSettings.getRptID());
				reportSettingsElm.setAttribute("trgOps", reportSettings.getTrgOps());

			}

			Element dataTypeTemplatesElm = XMLUtil.createChildElement(sCLElm, "DataTypeTemplates");
			DataTypeTemplates dataTypeTemplates = sCL.getDataTypeTemplates();
			dataTypeTemplatesElm.setTextContent(dataTypeTemplates.getTextContent());

			List<DOType> dOTypes = dataTypeTemplates.getDOTypes();

			dOTypes.forEach(dOType -> {

				Element dOTypeElm = XMLUtil.createChildElement(dataTypeTemplatesElm, "DOType");
				dOTypeElm.setTextContent(dOType.getTextContent());

				dOTypeElm.setAttribute("cdc", dOType.getCdc());
				dOTypeElm.setAttribute("id", dOType.getId());

				for (int k = 0; k < dOType.getDAList().size(); k++) {
					DA dA = dOType.getDAList().get(k);
					Element dAElm = XMLUtil.createChildElement(dOTypeElm, "DA");
					dAElm.setTextContent(dA.getTextContent());

					Val v = dA.getVal();
					if (Objects.nonNull(v) && Objects.nonNull(v.getTextContent())
							&& !StringUtils.isEmpty(v.getTextContent())) {
						Element valElms = XMLUtil.createChildElement(dAElm, "Val");
						valElms.setTextContent(v.getTextContent());
					}
					dAElm.setAttribute("bType", dA.getBType());
					dAElm.setAttribute("dchg", dA.getDchg());
					dAElm.setAttribute("fc", dA.getFc());
					dAElm.setAttribute("name", dA.getName());
					dAElm.setAttribute("type", dA.getType());
					dAElm.setAttribute("valKind", dA.getValKind());

				}

				for (int k = 0; k < dOType.getSDO().size(); k++) {
					SDO dA = dOType.getSDO().get(k);
					Element dAElm = XMLUtil.createChildElement(dOTypeElm, "SDO");

					dAElm.setAttribute("count", dA.getCount());
					dAElm.setAttribute("name", dA.getName());
					dAElm.setAttribute("type", dA.getType());

				}

			});

			dOTypes.forEach(dOType -> {

				Element dOTypeElm = XMLUtil.createChildElement(dataTypeTemplatesElm, "DAType");
				dOTypeElm.setTextContent(dOType.getTextContent());
				dOTypeElm.setAttribute("id", dOType.getId());

				if (Objects.nonNull(dOType.getProtNs())) {

					Element protNs = XMLUtil.createChildElement(dOTypeElm, "ProtNs");
					protNs.setTextContent(dOType.getProtNs().getTextContent());
				}

				for (int k = 0; k < dOType.getDAList().size(); k++) {
					DA dA = dOType.getDAList().get(k);
					Element dAElm = XMLUtil.createChildElement(dOTypeElm, "BDA");
					dAElm.setTextContent(dA.getTextContent());

					Val v = dA.getVal();
					if (Objects.nonNull(v) && Objects.nonNull(v.getTextContent())
							&& !StringUtils.isEmpty(v.getTextContent())) {
						Element valElms = XMLUtil.createChildElement(dAElm, "Val");
						valElms.setTextContent(v.getTextContent());
					}
					dAElm.setAttribute("bType", dA.getBType());
					dAElm.setAttribute("dchg", dA.getDchg());
					dAElm.setAttribute("fc", dA.getFc());
					dAElm.setAttribute("name", dA.getName());
					dAElm.setAttribute("type", dA.getType());
					dAElm.setAttribute("valKind", dA.getValKind());

				}

			});

			// REPEAt elm

			List<EnumType> enumTypes = dataTypeTemplates.getEnumType();
			enumTypes.forEach(enumType -> {
				Element enumTypeElm = XMLUtil.createChildElement(dataTypeTemplatesElm, "EnumType");
				enumTypeElm.setTextContent(enumType.getTextContent());

				enumTypeElm.setAttribute("id", enumType.getId());

				Element enumValElm = XMLUtil.createChildElement(enumTypeElm, "EnumVal");
				List<EnumVal> enumVals = enumType.getEnumVal();
				enumVals.forEach(enumVal -> {
					enumValElm.setTextContent(enumVal.getTextContent());

					enumValElm.setAttribute("ord", enumVal.getOrd());
				});
			});

			List<LNodeType> lNodeTypes = dataTypeTemplates.getLNodeType();
			lNodeTypes.forEach(lNodeType -> {
				Element lNodeTypeElm = XMLUtil.createChildElement(dataTypeTemplatesElm, "LNodeType");

				lNodeTypeElm.setTextContent(lNodeType.getTextContent());

				lNodeTypeElm.setAttribute("id", lNodeType.getId());
				lNodeTypeElm.setAttribute("lnClass", lNodeType.getLnClass());

				List<DO> dOs = lNodeType.getDOs();

				dOs.forEach(dO -> {
					Element dOElm = XMLUtil.createChildElement(lNodeTypeElm, "DO");

					dOElm.setTextContent(dO.getTextContent());

					dOElm.setAttribute("name", dO.getName());
					dOElm.setAttribute("type", dO.getType());

				});
			});

			return inputDoc;
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		return null;
	}
}
