package com.example.xml.utils;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.example.xml.model.AccessPoint;
import com.example.xml.model.Address;
import com.example.xml.model.BitRate;
import com.example.xml.model.ClientServices;
import com.example.xml.model.Communication;
import com.example.xml.model.ConfDataSet;
import com.example.xml.model.ConfReportControl;
import com.example.xml.model.ConnectedAP;
import com.example.xml.model.DA;
import com.example.xml.model.DAI;
import com.example.xml.model.DO;
import com.example.xml.model.DOI;
import com.example.xml.model.DOType;
import com.example.xml.model.DataTypeTemplates;
import com.example.xml.model.DynAssociation;
import com.example.xml.model.EnumType;
import com.example.xml.model.EnumVal;
import com.example.xml.model.ExtRef;
import com.example.xml.model.GOOSE;
import com.example.xml.model.GSE;
import com.example.xml.model.Header;
import com.example.xml.model.IED;
import com.example.xml.model.Inputs;
import com.example.xml.model.LDevice;
import com.example.xml.model.LN;
import com.example.xml.model.LN0;
import com.example.xml.model.LNodeType;
import com.example.xml.model.MaxTime;
import com.example.xml.model.MinTime;
import com.example.xml.model.P;
import com.example.xml.model.Private;
import com.example.xml.model.ProtNs;
import com.example.xml.model.ReportSettings;
import com.example.xml.model.SCL;
import com.example.xml.model.SDO;
import com.example.xml.model.Server;
import com.example.xml.model.Services;
import com.example.xml.model.SubNetwork;
import com.example.xml.model.Val;

import lombok.extern.slf4j.Slf4j;

public class XMLToBeanObjUtil {

	public static SCL convertXmlToBeanObject(Document doc) {

		try {
			Element sCLElm = doc.getDocumentElement();
			SCL sCL = new SCL();

			sCL.setRelease(sCLElm.getAttribute("release"));
			sCL.setRevision(sCLElm.getAttribute("revision"));
			sCL.setSchemaLocation(sCLElm.getAttribute("schemaLocation"));
			sCL.setVersion(sCLElm.getAttribute("version"));
			sCL.setTextContent(XMLUtil.getFirstLevelTextContent(sCLElm));

			Element communicationElm = XMLUtil.getChildElement(sCLElm, "Communication");
			Communication communication = new Communication();
			sCL.setCommunication(communication);

			communication.setTextContent(XMLUtil.getFirstLevelTextContent(communicationElm));

			List<Element> subNetworkElms = XMLUtil.getChildElements(communicationElm, "SubNetwork");
			List<SubNetwork> subNetworks = new ArrayList<>();
			for (Element subNetworkElm : subNetworkElms) {
				SubNetwork subNetwork = new SubNetwork();

				subNetwork.setName(subNetworkElm.getAttribute("name"));
				subNetwork.setType(subNetworkElm.getAttribute("type"));
				subNetwork.setTextContent(XMLUtil.getFirstLevelTextContent(subNetworkElm));
				subNetwork.setDesc(subNetworkElm.getAttribute("desc"));

				Element biterateElm = XMLUtil.getChildElement(subNetworkElm, "BitRate");

				BitRate bitRate = new BitRate();
				bitRate.setUnit(biterateElm.getAttribute("unit"));
				bitRate.setMultiplier(biterateElm.getAttribute("multiplier"));
				bitRate.setTextContent(XMLUtil.getFirstLevelTextContent(biterateElm));

				subNetwork.setBitRate(bitRate);

				List<Element> connectedAPElms = XMLUtil.getChildElements(subNetworkElm, "ConnectedAP");
				List<ConnectedAP> connectedAPs = new ArrayList<>();
				for (Element connectedAPElm : connectedAPElms) {

//				Element connectedAPElm = XMLUtil.getChildElement(subNetworkElm, "ConnectedAP");
					ConnectedAP connectedAP = new ConnectedAP();
//				subNetwork.setConnectedAP(connectedAP);

					connectedAP.setApName(connectedAPElm.getAttribute("apName"));
					connectedAP.setIedName(connectedAPElm.getAttribute("iedName"));
					connectedAP.setRedProt(connectedAPElm.getAttribute("redProt"));
					connectedAP.setTextContent(XMLUtil.getFirstLevelTextContent(connectedAPElm));

					Element addressElm = XMLUtil.getChildElement(connectedAPElm, "Address");
					Address address = new Address();
					connectedAP.setAddress(address);

					address.setTextContent(XMLUtil.getFirstLevelTextContent(addressElm));

					List<Element> pNdList = XMLUtil.getChildElements(addressElm, "P");
					List<P> pList = new ArrayList<P>();
					address.setPList(pList);
					for (Element pElm : pNdList) {
						P p = new P();
						pList.add(p);
						p.setTextContent(XMLUtil.getFirstLevelTextContent(pElm));
						p.setType(pElm.getAttribute("type"));

					}

					List<Element> gSENdList = XMLUtil.getChildElements(connectedAPElm, "GSE");
					List<GSE> gSEList = new ArrayList<GSE>();
					connectedAP.setGSEList(gSEList);
					for (Element gSEElm : gSENdList) {
						GSE gSE = new GSE();
						gSEList.add(gSE);

						gSE.setIsMulti(gSEElm.getAttribute("IsMulti"));
						gSE.setCbName(gSEElm.getAttribute("cbName"));
						gSE.setLdInst(gSEElm.getAttribute("ldInst"));

						List<Element> privateNdList = XMLUtil.getChildElements(gSEElm, "Private");
						List<Private> privateList = new ArrayList<Private>();
						gSE.setPrivateList(privateList);
						for (Element privateElm : privateNdList) {
							Private private1 = new Private();
							privateList.add(private1);

							private1.setType(privateElm.getAttribute("type"));

						}
						List<Element> addressNdList = XMLUtil.getChildElements(gSEElm, "Address");
						List<Address> addressList = new ArrayList<Address>();
						gSE.setAddressList(addressList);
						for (Element addressElm1 : addressNdList) {
							Address address1 = new Address();
							addressList.add(address1);

							List<Element> pNdList1 = XMLUtil.getChildElements(addressElm1, "P");
							List<P> pList1 = new ArrayList<P>();
							address1.setPList(pList1);
							for (Element pElm1 : pNdList1) {
								P p = new P();
								pList1.add(p);
								p.setTextContent(XMLUtil.getFirstLevelTextContent(pElm1));
								p.setType(pElm1.getAttribute("type"));

							}

						}
						Element minTimeElm = XMLUtil.getChildElement(gSEElm, "MinTime");
						MinTime minTime = new MinTime();
						minTime.setMultiplier(minTimeElm.getAttribute("multiplier"));
						minTime.setUnit(minTimeElm.getAttribute("unit"));
						gSE.setMinTime(minTime);
						Element maxTimeElm = XMLUtil.getChildElement(gSEElm, "MaxTime");
						MaxTime maxTime = new MaxTime();
						maxTime.setMultiplier(maxTimeElm.getAttribute("multiplier"));
						maxTime.setUnit(maxTimeElm.getAttribute("unit"));
						gSE.setMaxTime(maxTime);

					}

					Element dataTypeTemplatesElm = XMLUtil.getChildElement(sCLElm, "DataTypeTemplates");
					DataTypeTemplates dataTypeTemplates = new DataTypeTemplates();
					sCL.setDataTypeTemplates(dataTypeTemplates);

					dataTypeTemplates.setTextContent(XMLUtil.getFirstLevelTextContent(dataTypeTemplatesElm));

					List<Element> dOTypeElms = XMLUtil.getChildElements(dataTypeTemplatesElm, "DOType");

					List<DOType> doTypes = new ArrayList<>();
					dOTypeElms.forEach(dOTypeElm -> {
						DOType dOType = new DOType();
						dOType.setCdc(dOTypeElm.getAttribute("cdc"));
						dOType.setId(dOTypeElm.getAttribute("id"));
						dOType.setTextContent(XMLUtil.getFirstLevelTextContent(dOTypeElm));

						List<Element> dANdList = XMLUtil.getChildElements(dOTypeElm, "DA");
						List<DA> dAList = new ArrayList<DA>();
						dOType.setDAList(dAList);
						for (Element dAElm : dANdList) {
							DA dA = new DA();
							dAList.add(dA);
							Element valElms = XMLUtil.getChildElement(dAElm, "Val");
							Val v = new Val();
							v.setTextContent(XMLUtil.getFirstLevelTextContent(valElms));
							dA.setVal(v);
							dA.setBType(dAElm.getAttribute("bType"));
							dA.setDchg(dAElm.getAttribute("dchg"));
							dA.setFc(dAElm.getAttribute("fc"));
							dA.setName(dAElm.getAttribute("name"));
							dA.setType(dAElm.getAttribute("type"));
							dA.setValKind(dAElm.getAttribute("valKind"));

						}

						List<Element> sDANdList = XMLUtil.getChildElements(dOTypeElm, "SDO");
						List<SDO> sDAList = new ArrayList<>();
						for (Element dAElm : sDANdList) {
							SDO dA = new SDO();
							sDAList.add(dA);
							dA.setName(dAElm.getAttribute("name"));
							dA.setType(dAElm.getAttribute("type"));
							dA.setCount(dAElm.getAttribute("count"));

						}
						dOType.setSDO(sDAList);
						doTypes.add(dOType);

					});
					dataTypeTemplates.setDOTypes(doTypes);

					List<Element> dATypeElms = XMLUtil.getChildElements(dataTypeTemplatesElm, "DAType");

					List<DOType> dATypes = new ArrayList<>();
					dATypeElms.forEach(dATypeElm -> {
						DOType dOType = new DOType();
						dOType.setCdc(dATypeElm.getAttribute("cdc"));
						dOType.setId(dATypeElm.getAttribute("id"));
						dOType.setTextContent(XMLUtil.getFirstLevelTextContent(dATypeElm));

						List<Element> dANdList = XMLUtil.getChildElements(dATypeElm, "BDA");
						List<DA> dAList = new ArrayList<DA>();
						dOType.setDAList(dAList);
						for (Element dAElm : dANdList) {
							DA dA = new DA();
							dAList.add(dA);
							Element valElms = XMLUtil.getChildElement(dAElm, "Val");
							Val v = new Val();
							v.setTextContent(XMLUtil.getFirstLevelTextContent(valElms));
							dA.setVal(v);
							dA.setBType(dAElm.getAttribute("bType"));
							dA.setDchg(dAElm.getAttribute("dchg"));
							dA.setFc(dAElm.getAttribute("fc"));
							dA.setName(dAElm.getAttribute("name"));
							dA.setType(dAElm.getAttribute("type"));
							dA.setValKind(dAElm.getAttribute("valKind"));

						}

						Element protNs = XMLUtil.getChildElement(dATypeElm, "ProtNs");
						ProtNs protNs2 = new ProtNs(XMLUtil.getFirstLevelTextContent(protNs));
						dOType.setProtNs(protNs2);
						dATypes.add(dOType);

					});

					dataTypeTemplates.setDATypes(dATypes);

					List<Element> enumTypeElms = XMLUtil.getChildElements(dataTypeTemplatesElm, "EnumType");
					List<EnumType> enumTypes = new ArrayList<EnumType>();
					enumTypeElms.forEach(enumTypeElm -> {
						EnumType enumType = new EnumType();

						enumTypes.add(enumType);
						enumType.setId(enumTypeElm.getAttribute("id"));
						enumType.setTextContent(XMLUtil.getFirstLevelTextContent(enumTypeElm));

						List<Element> enumValElms = XMLUtil.getChildElements(enumTypeElm, "EnumVal");
						List<EnumVal> enumVals = new ArrayList<>();
						enumValElms.forEach(enumValElm -> {

							EnumVal enumVal = new EnumVal();
							enumVal.setOrd(enumValElm.getAttribute("ord"));
							enumVal.setTextContent(XMLUtil.getFirstLevelTextContent(enumValElm));
							enumVals.add(enumVal);
						});
						enumType.setEnumVal(enumVals);
					});
					dataTypeTemplates.setEnumType(enumTypes);

					List<Element> lNodeTypeElms = XMLUtil.getChildElements(dataTypeTemplatesElm, "LNodeType");
					List<LNodeType> lNodeTypes = new ArrayList<LNodeType>();

					lNodeTypeElms.forEach(lNodeTypeElm -> {
						LNodeType lNodeType = new LNodeType();

						lNodeType.setId(lNodeTypeElm.getAttribute("id"));
						lNodeType.setLnClass(lNodeTypeElm.getAttribute("lnClass"));
						lNodeType.setTextContent(XMLUtil.getFirstLevelTextContent(lNodeTypeElm));

						List<Element> dOElms = XMLUtil.getChildElements(lNodeTypeElm, "DO");

						List<DO> dos = new ArrayList<>();
						dOElms.forEach(dOElm -> {

							DO dO = new DO();

							dos.add(dO);
							dO.setName(dOElm.getAttribute("name"));
							dO.setType(dOElm.getAttribute("type"));
							dO.setTextContent(XMLUtil.getFirstLevelTextContent(dOElm));

						});
						lNodeType.setDOs(dos);

						lNodeTypes.add(lNodeType);
					});

					dataTypeTemplates.setLNodeType(lNodeTypes);
					Element headerElm = XMLUtil.getChildElement(sCLElm, "Header");
					Header header = new Header();
					sCL.setHeader(header);

					header.setId(headerElm.getAttribute("id"));
					header.setRevision(headerElm.getAttribute("revision"));
					header.setVersion(headerElm.getAttribute("version"));
					header.setTextContent(XMLUtil.getFirstLevelTextContent(headerElm));
					connectedAPs.add(connectedAP);

				}

				subNetwork.setConnectedAP(connectedAPs);
				subNetworks.add(subNetwork);
			}

			communication.setSubNetwork(subNetworks);

			Element iEDElm = XMLUtil.getChildElement(sCLElm, "IED");
			IED iED = new IED();
			sCL.setIED(iED);

			iED.setDesc(iEDElm.getAttribute("desc"));
			iED.setManufacturer(iEDElm.getAttribute("manufacturer"));
			iED.setName(iEDElm.getAttribute("name"));
			iED.setOriginalSclRelease(iEDElm.getAttribute("originalSclRelease"));
			iED.setOriginalSclRevision(iEDElm.getAttribute("originalSclRevision"));
			iED.setOriginalSclVersion(iEDElm.getAttribute("originalSclVersion"));
			iED.setType(iEDElm.getAttribute("type"));
			iED.setTextContent(XMLUtil.getFirstLevelTextContent(iEDElm));

			Element accessPointElm = XMLUtil.getChildElement(iEDElm, "AccessPoint");
			AccessPoint accessPoint = new AccessPoint();
			iED.setAccessPoint(accessPoint);

			accessPoint.setName(accessPointElm.getAttribute("name"));
			accessPoint.setTextContent(XMLUtil.getFirstLevelTextContent(accessPointElm));

			Element serverElm = XMLUtil.getChildElement(accessPointElm, "Server");
			Server server = new Server();
			accessPoint.setServer(server);

			server.setTextContent(XMLUtil.getFirstLevelTextContent(serverElm));

			Element lDeviceElm = XMLUtil.getChildElement(serverElm, "LDevice");
			LDevice lDevice = new LDevice();
			server.setLDevice(lDevice);

			lDevice.setDesc(lDeviceElm.getAttribute("desc"));
			lDevice.setInst(lDeviceElm.getAttribute("inst"));
			lDevice.setLdName(lDeviceElm.getAttribute("ldName"));
			lDevice.setTextContent(XMLUtil.getFirstLevelTextContent(lDeviceElm));

			List<Element> lNNdList = XMLUtil.getChildElements(lDeviceElm, "LN");
			List<LN> lNList = new ArrayList<LN>();
			lDevice.setLNList(lNList);
			for (Element lNElm : lNNdList) {
				LN lN = new LN();
				lNList.add(lN);

				lN.setInst(lNElm.getAttribute("inst"));
				lN.setLnClass(lNElm.getAttribute("lnClass"));
				lN.setLnType(lNElm.getAttribute("lnType"));

				Element dOIElm = XMLUtil.getChildElement(lNElm, "DOI");
				DOI dOI = new DOI();
				lN.setDOI(dOI);

				dOI.setName(dOIElm.getAttribute("name"));
				dOI.setTextContent(XMLUtil.getFirstLevelTextContent(dOIElm));

				List<Element> dAINdList = XMLUtil.getChildElements(dOIElm, "DAI");
				List<DAI> dAIList = new ArrayList<DAI>();
				dOI.setDAIList(dAIList);
				for (Element dAIElm : dAINdList) {
					DAI dAI = new DAI();
					dAIList.add(dAI);

					dAI.setVal(dAIElm.getAttribute("Val"));
					dAI.setName(dAIElm.getAttribute("name"));
					dAI.setValImport(dAIElm.getAttribute("valImport"));
					dAI.setValKind(dAIElm.getAttribute("valKind"));

				}
			}
			List<Element> lN0NdList = XMLUtil.getChildElements(lDeviceElm, "LN0");
			List<LN0> lN0List = new ArrayList<LN0>();
			lDevice.setLN0List(lN0List);
			for (Element lN0Elm : lN0NdList) {
				LN0 lN0 = new LN0();
				lN0List.add(lN0);

				lN0.setInst(lN0Elm.getAttribute("inst"));
				lN0.setLnClass(lN0Elm.getAttribute("lnClass"));
				lN0.setLnType(lN0Elm.getAttribute("lnType"));

				Element dOIElm = XMLUtil.getChildElement(lN0Elm, "DOI");
				DOI dOI = new DOI();
				lN0.setDOI(dOI);

				dOI.setName(dOIElm.getAttribute("name"));
				dOI.setTextContent(XMLUtil.getFirstLevelTextContent(dOIElm));

				List<Element> dAINdList = XMLUtil.getChildElements(dOIElm, "DAI");
				List<DAI> dAIList = new ArrayList<DAI>();
				dOI.setDAIList(dAIList);
				for (Element dAIElm : dAINdList) {
					DAI dAI = new DAI();
					dAIList.add(dAI);

					dAI.setName(dAIElm.getAttribute("name"));
					dAI.setSAddr(dAIElm.getAttribute("sAddr"));

				}
				Element inputsElm = XMLUtil.getChildElement(lN0Elm, "Inputs");
				Inputs inputs = new Inputs();
				lN0.setInputs(inputs);

				inputs.setTextContent(XMLUtil.getFirstLevelTextContent(inputsElm));

				Element extRefElm = XMLUtil.getChildElement(inputsElm, "ExtRef");
				ExtRef extRef = new ExtRef();
				inputs.setExtRef(extRef);

				extRef.setDesc(extRefElm.getAttribute("desc"));
				extRef.setIntAddr(extRefElm.getAttribute("intAddr"));
				extRef.setPDA(extRefElm.getAttribute("pDA"));
				extRef.setPDO(extRefElm.getAttribute("pDO"));
				extRef.setPLN(extRefElm.getAttribute("pLN"));
				extRef.setTextContent(XMLUtil.getFirstLevelTextContent(extRefElm));

			}
			Element privateElm1 = XMLUtil.getChildElement(iEDElm, "Private");
			Private private2 = new Private();
			iED.setPrivate1(private2);

			private2.setType(privateElm1.getAttribute("type"));
			private2.setTextContent(XMLUtil.getFirstLevelTextContent(privateElm1));

			Element servicesElm = XMLUtil.getChildElement(iEDElm, "Services");
			Services services = new Services();
			iED.setServices(services);

			services.setConfLNs(servicesElm.getAttribute("ConfLNs"));
			services.setDataObjectDirectory(servicesElm.getAttribute("DataObjectDirectory"));
			services.setDataSetDirectory(servicesElm.getAttribute("DataSetDirectory"));
			services.setFileHandling(servicesElm.getAttribute("FileHandling"));
			services.setGSESettings(servicesElm.getAttribute("GSESettings"));
			services.setGetCBValues(servicesElm.getAttribute("GetCBValues"));
			services.setGetDataObjectDefinition(servicesElm.getAttribute("GetDataObjectDefinition"));
			services.setGetDataSetValue(servicesElm.getAttribute("GetDataSetValue"));
			services.setGetDirectory(servicesElm.getAttribute("GetDirectory"));
			services.setReadWrite(servicesElm.getAttribute("ReadWrite"));
			services.setNameLength(servicesElm.getAttribute("nameLength"));
			services.setTextContent(XMLUtil.getFirstLevelTextContent(servicesElm));

			Element clientServicesElm = XMLUtil.getChildElement(servicesElm, "ClientServices");
			ClientServices clientServices = new ClientServices();
			services.setClientServices(clientServices);

			clientServices.setTimeSyncProt(clientServicesElm.getAttribute("TimeSyncProt"));
			clientServices.setTextContent(XMLUtil.getFirstLevelTextContent(clientServicesElm));

			Element confDataSetElm = XMLUtil.getChildElement(servicesElm, "ConfDataSet");
			ConfDataSet confDataSet = new ConfDataSet();
			services.setConfDataSet(confDataSet);

			confDataSet.setMax(confDataSetElm.getAttribute("max"));
			confDataSet.setMaxAttributes(confDataSetElm.getAttribute("maxAttributes"));
			confDataSet.setModify(confDataSetElm.getAttribute("modify"));
			confDataSet.setTextContent(XMLUtil.getFirstLevelTextContent(confDataSetElm));

			Element confReportControlElm = XMLUtil.getChildElement(servicesElm, "ConfReportControl");
			ConfReportControl confReportControl = new ConfReportControl();
			services.setConfReportControl(confReportControl);

			confReportControl.setBufConf(confReportControlElm.getAttribute("bufConf"));
			confReportControl.setMax(confReportControlElm.getAttribute("max"));
			confReportControl.setTextContent(XMLUtil.getFirstLevelTextContent(confReportControlElm));

			Element dynAssociationElm = XMLUtil.getChildElement(servicesElm, "DynAssociation");
			DynAssociation dynAssociation = new DynAssociation();
			services.setDynAssociation(dynAssociation);

			dynAssociation.setMax(dynAssociationElm.getAttribute("max"));
			dynAssociation.setTextContent(XMLUtil.getFirstLevelTextContent(dynAssociationElm));

			Element gOOSEElm = XMLUtil.getChildElement(servicesElm, "GOOSE");
			GOOSE gOOSE = new GOOSE();
			services.setGOOSE(gOOSE);

			gOOSE.setMax(gOOSEElm.getAttribute("max"));
			gOOSE.setTextContent(XMLUtil.getFirstLevelTextContent(gOOSEElm));

			Element reportSettingsElm = XMLUtil.getChildElement(servicesElm, "ReportSettings");
			ReportSettings reportSettings = new ReportSettings();
			services.setReportSettings(reportSettings);

			reportSettings.setBufTime(reportSettingsElm.getAttribute("bufTime"));
			reportSettings.setCbName(reportSettingsElm.getAttribute("cbName"));
			reportSettings.setDatSet(reportSettingsElm.getAttribute("datSet"));
			reportSettings.setIntgPd(reportSettingsElm.getAttribute("intgPd"));
			reportSettings.setOptFields(reportSettingsElm.getAttribute("optFields"));
			reportSettings.setOwner(reportSettingsElm.getAttribute("owner"));
			reportSettings.setResvTms(reportSettingsElm.getAttribute("resvTms"));
			reportSettings.setRptID(reportSettingsElm.getAttribute("rptID"));
			reportSettings.setTrgOps(reportSettingsElm.getAttribute("trgOps"));
			reportSettings.setTextContent(XMLUtil.getFirstLevelTextContent(reportSettingsElm));

			return sCL;

		} catch (Exception e) {
			e.printStackTrace();

		}
		return null;
	}
}